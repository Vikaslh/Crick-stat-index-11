import pandas as pd
import model

bowler_t20 = pd.read_csv(
    "C:\\Users\\Home\\Documents\\Crick-stat-index-11\\Viki\\data.csv")
# bowler_t20.head(20)

# features considered.
features = ['Player', 'Bowl_Ave', 'Bowl_SSR',
            'Wkts', 'Econ', 'Team', 'Overs', 'Mdns']
# remove rows not dont have numerical value from the features.
bowler_t20 = bowler_t20.dropna(subset=features)
bowler_t20 = bowler_t20[features].copy()
# bowler_t20

bowler_t20 = bowler_t20.dropna()  # removing incorrect data

# features considered.
features = ['Bowl_Ave', 'Bowl_SSR', 'Wkts', 'Econ', 'Overs', 'Mdns']

scaled = model.scale_data(bowler_t20, features)
# using kmeans to form clusters.
data = model.kmeansCluster(scaled[0], scaled[1])
# print(data)

# print(data['Cluster'].value_counts())

best_bowler = model.find_best_cluster(data, 3)
# best_bowler = model.cluster_team(data, 'Team', 'INDIA')
best_bowler = best_bowler.loc[best_bowler['Team'] == 'INDIA']
# print(best_bowler)
