import gradio as gr
import run


def greet(name):
    return run.sample


demo = gr.Interface(fn=greet, inputs="text", outputs="text")

demo.launch()
