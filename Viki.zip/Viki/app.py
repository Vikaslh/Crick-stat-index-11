import gradio as gr
import run


def greet(name):
    return name


demo = gr.Interface(fn=greet, inputs="text", outputs="text")

demo.launch()
