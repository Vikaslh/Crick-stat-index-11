from batsman import best_batsman
from bowler import best_bowler
from rounder import best_allrounder
import app


def select_player(batsmen_no, bowler_no, keeper_no):
    players = []
    i = 0
    while i in range(0, batsmen_no):
        temp = best_batsman['Player'].tolist()
        if not temp[i] in players:
            players.append(temp[i])
            i += 1
    i = 0
    while i in range(0, bowler_no):
        temp = best_bowler['Player'].tolist()
        print(temp)
        if not temp[i] in players:
            players.append(temp[i])
            i += 1
    i = 0
    while i in range(0, keeper_no):
        temp = best_allrounder['Player'].sample().tolist()
        if not temp[0] in players:
            players.append(temp[0])
            i += 1
    i = 0
    return players


p = select_player()
print(p)

sample = "Vignesh S"
